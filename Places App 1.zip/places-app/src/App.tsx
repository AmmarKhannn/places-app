import { useEffect, useState, type FormEvent } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import './style.css';

type Place = {
  ID: number;
  Name: string;
  Latitude: number;
  Longitude: number;
  UserID: number;
};

const API = import.meta.env.VITE_SERVER_URL || 'http://localhost:3000';

// This component moves the map when we click a place in the list.
function MoveMap({ place }: { place: Place | undefined }) {
  const map = useMap();
  useEffect(() => {
    if (place) map.flyTo([place.Latitude, place.Longitude], Math.max(map.getZoom(), 14));
  }, [place, map]);
  return null;
}

const selectedIcon = new L.Icon({
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  iconSize: [32, 52], iconAnchor: [16, 52], popupAnchor: [0, -46], shadowSize: [41, 41],
});

function App() {
  const [places, setPlaces] = useState<Place[]>([]);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [token, setToken] = useState(localStorage.getItem('places_token') || '');
  const [username, setUsername] = useState(localStorage.getItem('places_username') || '');
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [loginName, setLoginName] = useState('');
  const [password, setPassword] = useState('');
  const [placeName, setPlaceName] = useState('');
  const [latitude, setLatitude] = useState('62.59');
  const [longitude, setLongitude] = useState('29.77');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  async function getAllPlaces() {
    try {
      const response = await fetch(`${API}/api/places`);
      if (!response.ok) throw new Error('Could not load places. Is the server running?');
      const data: Place[] = await response.json();
      setPlaces(data);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Something went wrong.');
    }
  }

  useEffect(() => { void getAllPlaces(); }, []);
  const selectedPlace = places.find(place => place.ID === selectedId);

  async function submitAuth(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true); setMessage('');
    try {
      const response = await fetch(`${API}/api/${authMode}`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: loginName, password }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Something went wrong.');
      if (authMode === 'login') {
        localStorage.setItem('places_token', data.token);
        localStorage.setItem('places_username', data.username);
        setToken(data.token); setUsername(data.username);
        setMessage('Logged in! You can add places now.');
      } else {
        setAuthMode('login');
        setMessage('Account created! Please log in.');
      }
      setPassword('');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Something went wrong.');
    } finally { setLoading(false); }
  }

  async function addPlace(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!token) return;
    setLoading(true); setMessage('');
    try {
      const response = await fetch(`${API}/api/places`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ name: placeName, latitude: Number(latitude), longitude: Number(longitude) }),
      });
      const data = await response.json();
      if (!response.ok) {
        if (response.status === 401) logout();
        throw new Error(data.error || 'Could not add place.');
      }
      await getAllPlaces();
      setSelectedId(data.ID);
      setPlaceName('');
      setMessage('Place added!');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Something went wrong.');
    } finally { setLoading(false); }
  }

  function logout() {
    localStorage.removeItem('places_token');
    localStorage.removeItem('places_username');
    setToken(''); setUsername('');
  }

  return (
    <div className="app">
      <header>
        <div><h1>📍 My Places</h1><p>Find places and save your favorites</p></div>
        {token && <button className="logout" onClick={logout}>Log out ({username})</button>}
      </header>

      {message && <p className="message" role="status">{message}</p>}

      <main>
        <section className="places-panel">
          <h2>Places <span>({places.length})</span></h2>
          <p className="hint">Click a place to find it on the map.</p>
          {places.length === 0 ? <p>No places yet. Add the first one!</p> : (
            <ul className="place-list">
              {places.map(place => (
                <li key={place.ID}>
                  <button className={selectedId === place.ID ? 'place active' : 'place'}
                    onClick={() => setSelectedId(place.ID)}>
                    <strong>{place.Name}</strong>
                    <small>{place.Latitude.toFixed(4)}, {place.Longitude.toFixed(4)}</small>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="map-panel" aria-label="Map of places">
          <MapContainer center={[62.59, 29.77]} zoom={12} scrollWheelZoom={true} className="map">
            <TileLayer attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
            <MoveMap place={selectedPlace} />
            {places.map(place => (
              <Marker key={place.ID} position={[place.Latitude, place.Longitude]}
                icon={selectedId === place.ID ? selectedIcon : undefined}
                eventHandlers={{ click: () => setSelectedId(place.ID) }}>
                <Popup>{place.Name}</Popup>
              </Marker>
            ))}
          </MapContainer>
        </section>
      </main>

      <section className="form-panel">
        {token ? (
          <>
            <h2>Add a new place</h2>
            <p className="hint">Enter the name and coordinates of your place.</p>
            <form onSubmit={addPlace}>
              <label>Place name<input required maxLength={80} value={placeName} onChange={event => setPlaceName(event.target.value)} placeholder="e.g. My school" /></label>
              <label>Latitude<input required type="number" min={-90} max={90} step="any" value={latitude} onChange={event => setLatitude(event.target.value)} /></label>
              <label>Longitude<input required type="number" min={-180} max={180} step="any" value={longitude} onChange={event => setLongitude(event.target.value)} /></label>
              <button className="primary" disabled={loading}>{loading ? 'Saving...' : 'Add place'}</button>
            </form>
          </>
        ) : (
          <>
            <h2>{authMode === 'login' ? 'Log in to add places' : 'Create an account'}</h2>
            <form onSubmit={submitAuth}>
              <label>Username<input required minLength={3} maxLength={30} value={loginName} onChange={event => setLoginName(event.target.value)} /></label>
              <label>Password<input required minLength={6} type="password" value={password} onChange={event => setPassword(event.target.value)} /></label>
              <button className="primary" disabled={loading}>{loading ? 'Please wait...' : authMode === 'login' ? 'Log in' : 'Register'}</button>
            </form>
            <button className="switch" onClick={() => { setAuthMode(authMode === 'login' ? 'register' : 'login'); setMessage(''); }}>
              {authMode === 'login' ? 'No account? Register here' : 'Already have an account? Log in'}
            </button>
          </>
        )}
      </section>
      <footer>Made for the Places App exercise</footer>
    </div>
  );
}

export default App;
