// Small backend for our Places App. Uses the SQLite database included in Node 22.
import { createServer } from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { randomBytes, scryptSync, createHmac, timingSafeEqual } from 'node:crypto';
import { mkdirSync } from 'node:fs';

mkdirSync('server/data', { recursive: true });
const db = new DatabaseSync('server/data/places.db');
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS places (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    latitude REAL NOT NULL,
    longitude REAL NOT NULL,
    user_id INTEGER NOT NULL REFERENCES users(id)
  );
`);
const secret = process.env.TOKEN_SECRET || randomBytes(32).toString('hex');
if (!process.env.TOKEN_SECRET) console.log('Using a temporary token secret. Logins reset when the server restarts.');
const port = Number(process.env.PORT || 3000);

function json(res, status, data) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': 'http://localhost:5173',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS' });
  res.end(JSON.stringify(data));
}
function sign(payload) {
  const body = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const signature = createHmac('sha256', secret).update(body).digest('base64url');
  return `${body}.${signature}`;
}
function getUserId(req) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  const [body, signature] = token.split('.');
  if (!body || !signature) return null;
  const expected = createHmac('sha256', secret).update(body).digest();
  let received;
  try { received = Buffer.from(signature, 'base64url'); } catch { return null; }
  if (received.length !== expected.length || !timingSafeEqual(received, expected)) return null;
  try {
    const parsed = JSON.parse(Buffer.from(body, 'base64url').toString());
    return Number.isInteger(parsed.id) && parsed.exp > Date.now() ? parsed.id : null;
  } catch { return null; }
}
async function readBody(req) {
  let body = '';
  for await (const part of req) {
    body += part;
    if (body.length > 10000) throw new Error('Request is too large');
  }
  return JSON.parse(body || '{}');
}
const server = createServer(async (req, res) => {
  if (req.method === 'OPTIONS') return json(res, 200, {});
  const path = new URL(req.url || '/', 'http://localhost').pathname;
  try {
    if (req.method === 'GET' && path === '/api/places') {
      const rows = db.prepare('SELECT id AS ID, name AS Name, latitude AS Latitude, longitude AS Longitude, user_id AS UserID FROM places ORDER BY id DESC').all();
      return json(res, 200, rows);
    }
    if (req.method === 'POST' && path === '/api/register') {
      const { username, password } = await readBody(req);
      if (typeof username !== 'string' || username.trim().length < 3 || username.trim().length > 30 ||
          typeof password !== 'string' || password.length < 6) {
        return json(res, 400, { error: 'Username must be 3–30 characters and password at least 6.' });
      }
      if (db.prepare('SELECT id FROM users WHERE username = ?').get(username.trim())) {
        return json(res, 409, { error: 'That username is already taken.' });
      }
      const salt = randomBytes(16).toString('hex');
      const hash = `${salt}:${scryptSync(password, salt, 64).toString('hex')}`;
      db.prepare('INSERT INTO users (username, password_hash) VALUES (?, ?)').run(username.trim(), hash);
      return json(res, 201, { message: 'Account created! You can log in now.' });
    }
    if (req.method === 'POST' && path === '/api/login') {
      const { username, password } = await readBody(req);
      const user = typeof username === 'string' && db.prepare('SELECT id, password_hash FROM users WHERE username = ?').get(username.trim());
      if (!user || typeof password !== 'string') return json(res, 401, { error: 'Wrong username or password.' });
      const [salt, saved] = user.password_hash.split(':');
      const calculated = scryptSync(password, salt, 64);
      if (!timingSafeEqual(calculated, Buffer.from(saved, 'hex'))) return json(res, 401, { error: 'Wrong username or password.' });
      return json(res, 200, { token: sign({ id: user.id, exp: Date.now() + 24 * 60 * 60 * 1000 }), username: username.trim() });
    }
    if (req.method === 'POST' && path === '/api/places') {
      const userId = getUserId(req);
      if (!userId || !db.prepare('SELECT id FROM users WHERE id = ?').get(userId)) {
        return json(res, 401, { error: 'Please log in again.' });
      }
      const { name, latitude, longitude } = await readBody(req);
      if (typeof name !== 'string' || !name.trim() || name.trim().length > 80 ||
          typeof latitude !== 'number' || !Number.isFinite(latitude) || latitude < -90 || latitude > 90 ||
          typeof longitude !== 'number' || !Number.isFinite(longitude) || longitude < -180 || longitude > 180) {
        return json(res, 400, { error: 'Enter a name and valid coordinates.' });
      }
      const result = db.prepare('INSERT INTO places (name, latitude, longitude, user_id) VALUES (?, ?, ?, ?)').run(name.trim(), latitude, longitude, userId);
      return json(res, 201, { ID: Number(result.lastInsertRowid), Name: name.trim(), Latitude: latitude, Longitude: longitude, UserID: userId });
    }
    return json(res, 404, { error: 'Page not found.' });
  } catch (error) {
    console.error(error);
    return json(res, 400, { error: error instanceof SyntaxError ? 'Invalid JSON.' : 'Something went wrong.' });
  }
});
server.listen(port, () => console.log(`Places API: http://localhost:${port}`));
