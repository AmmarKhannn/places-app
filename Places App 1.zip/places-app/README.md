# My Places App (Day 2)

I continued my React + TypeScript project from class. The map is made with React Leaflet and OpenStreetMap.

## Features

- See all saved places in a list and on a map.
- Click a place in the list to move the map to it and highlight its marker.
- Click a map marker to highlight its place in the list.
- Register and log in. The login token is saved in localStorage.
- Logged-in users can save a new place to a SQLite database.
- Layout works on computers and phones.
- Extra feature: simple CSS styling and highlighted selected places.

## How to start

Use Node.js **22.13 or newer** (the server uses Node's built-in SQLite).

1. Open the project folder in VS Code.
2. Run `npm install`.
3. Open one terminal and run `npm run server`.
4. Open another terminal and run `npm run dev`.
5. Open the link shown by Vite (usually http://localhost:5173).

The backend is at http://localhost:3000, and the database file is created at `server/data/places.db`.

You can make an account with a username (3+ characters) and password (6+ characters). Log in, then add a name, latitude and longitude. You can use Joensuu coordinates `62.59, 29.77` for a test place.

## API endpoints

- `GET /api/places` — list places (public)
- `POST /api/register` — body: `{ "username": "...", "password": "..." }`
- `POST /api/login` — returns a token and username
- `POST /api/places` — body: `{ "name": "...", "latitude": 62.59, "longitude": 29.77 }`; needs the header `Authorization: Bearer YOUR_TOKEN`

## Notes

This ZIP originally only contained the frontend, so I made a small backend to test the database features locally. The login token expires after 24 hours. For a classroom project this is okay, but real apps should use HTTPS and stronger production authentication practices (often HttpOnly cookies rather than localStorage). Set `TOKEN_SECRET` in the server environment if you want logins to stay valid across server restarts.

I have not added edit/delete yet. That could be the next thing to try in class.

## Upload to GitHub

Create an empty repository called `places-app` on GitHub, then in the project folder run:

```bash
git init
git add .
git commit -m "Add login and places features"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/places-app.git
git push -u origin main
```

Replace `YOUR_USERNAME` with your own GitHub username. The SQLite database is ignored by git, so your personal test data won't be uploaded.
